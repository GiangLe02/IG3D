#ifndef _QUAD4_HPP_
#define _QUAD4_HPP_
#include <cassert>

#include "typedefs.hpp"
#include "Matrix3x3.hpp"
#include "Vector3.hpp"

template<typename T> class Vector3;

template<typename T> class Matrix3x3;

template<typename T>
class Quad4 {
public:
  enum { D = 4 };

  typedef T ValueT;

  union {
    struct { T s; T x; T y; T z;};
    struct { T i; T j; T k; T p;};
    T v[D];
  };

  explicit Quad4(const T &value=0) : x(value), y(value), z(value) {}
  Quad4(const T &a, const T &b, const T &c=0, const T &d=0): s(a), x(b), y(c), z(d) {}

  // assignment operators
  Quad4& operator+=(const Quad4 &r) { s+=r.s; x+=r.x; y+=r.y; z+=r.z; return *this; }
  Quad4& operator-=(const Quad4 &r) { s-=r.s; x-=r.x; y-=r.y; z-=r.z; return *this; }
  Quad4& operator*=(const Quad4 &r) { s*=r.s; x*=r.x; y*=r.y; z*=r.z; return *this; }
  Quad4& operator/=(const Quad4 &r) { s/=r.s; x/=r.x; y/=r.y; z/=r.z; return *this; }

  Quad4& operator+=(const T *r) { s+=r[0]; x+=r[1]; y+=r[2]; z+=r[3]; return *this; }
  Quad4& operator-=(const T *r) { s-=r[0]; x-=r[1]; y-=r[2]; z-=r[3]; return *this; }
  Quad4& operator*=(const T *r) { s*=r[0]; x*=r[1]; y*=r[2]; z*=r[3]; return *this; }
  Quad4& operator/=(const T *r) { s/=r[0]; x/=r[1]; y/=r[2]; z/=r[3]; return *this; }

  Quad4& operator+=(const T t) { s+=t; x+=t; y+=t; z+=t; return *this; }
  Quad4& operator-=(const T t) { s-=t; x-=t; y-=t; z-=t; return *this; }
  Quad4& operator*=(const T t) { s*=t; x*=t; y*=t; z*=t; return *this; }
  Quad4& operator/=(const T t) {
    const T d=static_cast<T>(1)/t; return operator*=(d);
  }

  // unary operators
  Quad4 operator+() const { return *this; }
  Quad4 operator-() const { return Quad4(-s, -x, -y, -z); }

  // binary operators
  Quad4 operator+(const Quad4 &r) const { return Quad4(*this)+=r; }
  Quad4 operator-(const Quad4 &r) const { return Quad4(*this)-=r; }
  Quad4 operator*(const Quad4 &r) const { return Quad4(*this)*=r; }
  Quad4 operator/(const Quad4 &r) const { return Quad4(*this)/=r; }

  Quad4 operator+(const T *r) const { return Quad4(*this)+=r; }
  Quad4 operator-(const T *r) const { return Quad4(*this)-=r; }
  Quad4 operator*(const T *r) const { return Quad4(*this)*=r; }
  Quad4 operator/(const T *r) const { return Quad4(*this)/=r; }

  Quad4 operator+(const T s) const { return Quad4(*this)+=s; }
  Quad4 operator-(const T s) const { return Quad4(*this)-=s; }
  Quad4 operator*(const T s) const { return Quad4(*this)*=s; }
  Quad4 operator/(const T s) const { return Quad4(*this)/=s; }

  // comparison operators
  bool operator==(const Quad4 &r) const {
    return ((s==r.s) && (x==r.x) && (y==r.y) && (z==r.z));
  }
  bool operator!=(const Quad4 &r) const { return !(*this==r); }
  bool operator<(const Quad4 &r) const {
    return (s!=r.s) ? s<r.s : (x!=r.x) ? x<r.x : (y!=r.y) ? y<r.y : z<r.z;
  }
  bool operator<=(const Quad4 &r) const {
    return (s!=r.s) ? s<=r.s : (x!=r.x) ? x<=r.x : (y!=r.y) ? y<=r.y : z<=r.z;
  }

  // cast operator
  template<typename T2>
  operator Quad4<T2>() const {
    return
      Quad4<T2>(static_cast<T2>(s),static_cast<T2>(x),static_cast<T2>(y),static_cast<T2>(z));
  }

  const T& operator[](const tIndex i) const { assert(i<D); return v[i]; }
  T& operator[](const tIndex i) {
    return const_cast<T &>(static_cast<const Quad4 &>(*this)[i]);
  }

  // special calculative functions

  Quad4& normalize() { return (s==0&&x==0&&y==0&&z==0) ? (*this):(*this)/=length(); }
  Quad4 normalized() const { return Quad4(*this).normalize(); }

  T dotProduct(const Quad4 &r) const { return s*r.s + x*r.x + y*r.y + z*r.z; }
//   Quad4 crossProduct(const Quad4 &r) const {
//     return Quad4(y*r.z - z*r.y, z*r.x - x*r.z, x*r.y - y*r.x);
//   }
//   Matrix3x3<T> crossProductMatrix() const {
//     return Matrix3x3<T>(0, -z, y,  z, 0, -x,  -y, x, 0);
//   }
  Matrix3x3<T> rotationMatrix() const {
    const T r00 = 1-2*y*y - 2*z*z;
    const T r10 = 2*x*y + 2*s*z;
    const T r20 = 2*x*z - 2*s*y;
    const T r01 = 2*x*y - 2*s*z;
    const T r11 = 1-2*x*x - 2*z*z;
    const T r21 = 2*y*z + 2*s*x;
    const T r02 = 2*x*z + 2*s*y;
    const T r12 = 2*y*z - 2*s*x;
    const T r22 = 1-2*x*x - 2*y*y;
    return Matrix3x3<T>(
      r00, r01, r02, 
      r10, r11, r12, 
      r20, r21, r22);
  }
  Quad4 quaternionProduct(const Quad4 &r) const{
    Vector3<T> w1(x,y,z);
    T s1 = s;
    T s2 = r.s;
    Vector3<T> w2(r.x,r.y,r.z);
    Vector3<T> w3 = s1*w2 + s2*w1 + w1.crossProduct(w2);
    return Quad4(s1*s2-w1.dotProduct(w2), w3.x, w3.y, w3.z);
  }


  T length() const { return std::sqrt(lengthSquare()); }
  T lengthSquare() const { return (s*s + x*x + y*y + z*z); }
  T distanceTo(const Quad4 &t) const { return (*this-t).length(); }
  T distanceSquareTo(const Quad4 &t) const { return (*this-t).lengthSquare(); }

  friend std::istream& operator>>(std::istream &in, Quad4 &vec) {
    return (in >> vec.x >> vec.y >> vec.z);
  }
  friend std::ostream& operator<<(std::ostream &out, const Quad4 &vec) {
    return (out << vec.x << " " << vec.y << " " << vec.z);
  }
};
typedef Quad4<tReal> Quad4f;

inline const Quad4f operator*(const tReal s, const Quad4f &r) { return r*s; }

#endif  /* _QUAD4_HPP_ */