// ----------------------------------------------------------------------------
// typedefs.hpp
//
//  Created on: 13 Feb 2020
//      Author: Kiwon Um
//        Mail: kiwon.um@telecom-paris.fr
//
// Description: Global renaming for types
//
// Copyright 2020-2024 Kiwon Um
//
// The copyright to the computer program(s) herein is the property of Kiwon Um,
// Telecom Paris, France. The program(s) may be used and/or copied only with
// the written permission of Kiwon Um or in accordance with the terms and
// conditions stipulated in the agreement/contract under which the program(s)
// have been supplied.
// ----------------------------------------------------------------------------

#ifndef _TYPEDEFS_H_
#define _TYPEDEFS_H_

typedef float tReal;
typedef unsigned int tIndex;

#endif  /* _TYPEDEFS_H_ */
